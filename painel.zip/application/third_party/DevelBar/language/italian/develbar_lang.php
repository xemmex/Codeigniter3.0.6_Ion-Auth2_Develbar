<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['version_not_supported'] = "Versione CodeIgniter non è supportata da DevelBar, controlla prego %s per l'aggiornamento.";
$lang['sec'] = 'sec';
$lang['request'] = 'Richiesta';
$lang['method'] = 'Metodo';
$lang['controller'] = 'Controller';
$lang['action'] = 'Action';
$lang['function'] = 'Funzione';
$lang['parameters'] = 'Parametri';
$lang['database'] = 'Database';
$lang['total_execution_time'] = 'Totale tempo impiegato';
$lang['no_queries'] = 'Sono stati eseguiti Nessun query';
$lang['benchmarks'] = 'Benchmarks';
$lang['hooks'] = 'Hooks';
$lang['libraries'] = 'Libraries';
$lang['config'] = 'Configurazione';
$lang['session'] = 'Session';
$lang['helpers'] = 'Helpers';
$lang['views'] = 'Views';
$lang['models'] = 'Models';
$lang['memory_usage'] = 'Utilizzo della memoria';
$lang['ci_version'] = 'CodeIgniter version : %s';
$lang['info'] = 'Info';
$lang['update_message'] = 'Aggiornamento è disponibile per %s';
$lang['develbar_version'] = 'DevelBar version : %s';
$lang['php_version'] = 'PHP version : %s';
$lang['default_language'] = 'Lingua di Default : %s';

